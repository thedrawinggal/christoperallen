<?php get_header(); ?>
<main id="content" class="container" style="text-align:center;">
<article id="post-0" class="post not-found">
<header class="header">
<h1 class="entry-title">OOPS, LOOKS LIKE SOMETHING IS MISSING.
</h1>
</header>
<div class="entry-content">
<p>It seems like you have tried to open a page that doesn't exist. It could have been deleted, moved, or it never existed at all.</p>
<a href="/"><button>Return Home</button></a>
</div>
</article>
</main>
<?php get_footer(); ?>
